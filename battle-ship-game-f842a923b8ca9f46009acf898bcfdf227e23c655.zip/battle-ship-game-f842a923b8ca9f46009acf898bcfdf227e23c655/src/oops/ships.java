package oops;

public interface ships {
public void placer(int i,int j,int s, int a,int n);
public void shipPostion(int i,int j,int s, int a, int length);
}
