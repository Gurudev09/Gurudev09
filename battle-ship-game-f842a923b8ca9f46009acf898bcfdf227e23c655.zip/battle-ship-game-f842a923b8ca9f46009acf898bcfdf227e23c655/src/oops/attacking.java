package oops;

public interface attacking {
	public void attack(Player one);
}
