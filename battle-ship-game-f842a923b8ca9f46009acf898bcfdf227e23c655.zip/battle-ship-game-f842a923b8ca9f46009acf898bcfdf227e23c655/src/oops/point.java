package oops;
public class point {
	private int i;
	private int j;
	private int r;
	private int s;
	public void setPoint(int i,int j,int r,int s) {
		this.i=i;
		this.j=j;
		this.r=r;
		this.s=s;
	}
	public int getI() {
		return i;
	}
	public int getJ() {
		return j;
	}
	public int getR() {
		return r;
	}
	public int getS() {
		return s;
	}
}
