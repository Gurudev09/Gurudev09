package oops;

public interface Navigation {
	 public void navigation(int i,int j);
}
